﻿namespace TaqTask.Application;

public class Class1
{

}
