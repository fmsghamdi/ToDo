﻿namespace TaqTask.Infrastructure;

public class Class1
{

}
