﻿namespace TaqTask.Domain;

public class Class1
{

}
